<?php
    //Single User
    require_once('mDbOps.php');
    
    $uEmail = $_GET["uEmail"];
    $page = $_GET["page"];
    
    $query = "SELECT * FROM users WHERE email = '".$uEmail."'"; 
    $stmt = $pdo ->prepare($query);
    $stmt->execute();
    $stmt->execute(array("%$query%"));
        
    while($row = $stmt->fetch()) {
       
        
        $qFPosts = "SELECT SUM(cost),SUM(reviewed),SUM(views) FROM posts WHERE uEmail = '".$uEmail."' "; /* More Queries */
        $stFpost = $pdo ->prepare($qFPosts);
        $stFpost->execute();
            
        while($rFpost = $stFpost->fetch()) {
                 
            $mTotalsInPosts = $rFpost['SUM(cost)'];
            $mTotalsReview = $rFpost['SUM(reviewed)'];
            $mTotalsView = $rFpost['SUM(views)'];
        }
         
        $qFAReviews = $pdo ->prepare("SELECT * FROM reviews WHERE uEmail = '".$uEmail."' "); /* More Queries */ 
        $qFAReviews->execute();
        
        $qFReviews = "SELECT SUM(review) FROM reviews WHERE uEmail = '".$uEmail."' "; /* More Queries */
        $stFReviews = $pdo ->prepare($qFReviews);
        $stFReviews->execute();
        $tReviews = $qFAReviews->rowCount();
         
        while($rFReviews = $stFReviews->fetch()) {
                 
            $mSumRev = $rFReviews['SUM(review)'];
            $avgRev = round($mSumRev / $tReviews);
        }
        
        /* Outed the Result */
        $result[] = [
            "uId"=>$row['uId'],
            "fUser"=>$row['fUser'],
            "firstname"=>$row['firstname'],
            "username"=>$row['username'],
            "email"=>$row['email'],
            "gender"=>$row['gender'],
            "status"=>$row['status'],
            "lastLoggedOn"=>$row['lastLoggedOn'], 
            "mTotalsView"=>$mTotalsView,
            "mTotalsInPosts"=>$mTotalsInPosts,
            "mTotalsReview"=>$mTotalsReview,
            "avgRev"=>$avgRev
                         
        ];
    } 
    
        
    echo json_encode($result);
    
    