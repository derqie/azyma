<?php
    require_once('mDbOps.php');
   
    $page = $_GET["page"];
    $offset = $_GET["offset"];
    $email = $_GET["email"];
    $posId = $_GET["posId"];
    $status="1"; //*ACCEPTED
    
    $start = 0; 
    $limit = 3;
    
    $qTotal = $pdo->prepare("SELECT * from reviews WHERE posId = '".$posId."' AND status != '".$status."' ");
	$qTotal->execute();
    $total = $qTotal->rowCount();
    
    $page_limit = $total/$limit; 
    
    if($page<=$page_limit){
       
        $start = ($page - 1) * $limit;
        $query = "SELECT * FROM reviews  WHERE posId = '".$posId."' AND status != '".$status."'  ";//*
        $stmt = $pdo ->prepare($query);
        $stmt->execute();
          
        $stmt->execute(array("%$query%"));
        while($row = $stmt->fetch()) {
            $result[] = [
                "revId"=>$row['revId'],
                "posId"=>$row['posId'],
                 "body"=>$row['body'],
                 "review"=>$row['review'],
                 "uFireId"=>$row['uFireId'],
                 "uEmail"=>$row['uEmail'],
                 "uName"=>$row['uName'],
                 "uPhone"=>$row['uPhone'],
                 "uPhoto"=>$row['uPhoto'],
                 "updated"=>$row['updated'],
                 "status"=>$row['status'],
                 "created"=>$row['created']
                 
            ];
    } 
        
    echo json_encode($result); 
 

}else{
   echo "over";
}
    
    