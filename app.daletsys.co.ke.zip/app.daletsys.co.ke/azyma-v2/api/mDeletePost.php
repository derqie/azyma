<?php
	require_once('mDbOps.php');
	$posId = $_POST['posId'];
	
	$result = $pdo ->prepare("DELETE FROM posts WHERE posId = :posId");
	$result->bindParam(':posId', $posId);
	$result->execute();
	
	if($result){
	    $response['success'] = "0";
        $response['message'] = "Post was deleted.";
        echo json_encode($response);
	}else{
	    $response['success'] = "1";
        $response['message'] = "Post was not deleted.";
        echo json_encode($response);
	}
   
?>