<?php
	require_once('mDbOps.php');
	$posId = $_POST['posId'];
	$dateNow = date("Y-m-d h:i:sa");
	
	$result = $pdo->prepare("SELECT * FROM posts WHERE posId = '".$posId."' "); 
    $result->execute();
      	 
    for($i=0; $row = $result->fetch(); $i++){
        
        $count = $row['views'];
        
        if($count == "" || $count == "" ){
            $count = "0";
            $count = $count+1;
        
            $updates = $pdo -> prepare("UPDATE posts SET views = ?,updated = ? WHERE posId = ? ");
            $saves = $updates->execute([$count,$dateNow,$posId]);
        	
        	if($saves){
        	    $response['success'] = "0";
                $response['message'] = "Post was Updated.";
                echo json_encode($response);
        	}else{
        	    $response['success'] = "1";
                $response['message'] = "Post was not updated.";
                echo json_encode($response);
        	}
        	
        }else{
            $count = $count+1;
        
            $updates = $pdo -> prepare("UPDATE posts SET views = ?,updated = ? WHERE posId = ? ");
            $saves = $updates->execute([$count,$dateNow,$posId]);
        	
        	if($saves){
        	    $response['success'] = "0";
                $response['message'] = "Post was Updated.";
                echo json_encode($response);
        	}else{
        	    $response['success'] = "1";
                $response['message'] = "Post was not updated.";
                echo json_encode($response);
        	}
        }
        
        
    }
	 
?>