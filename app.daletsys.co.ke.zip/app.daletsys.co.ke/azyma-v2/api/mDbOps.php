<?php
$hostname = "corporate.vip1.noc401.com";
$dbname = 'daletsys_azyma';
$username = 'daletsys_root';
$password = '#derrick1764';

try {
    $pdo = new PDO("mysql:host=".$hostname.";dbname=".$dbname, $username, $password);
} catch (PDOException $e) {
    exit("Error: " . $e->getMessage());
}

$con = mysqli_connect($hostname,$username,$password,$dbname) or die('Unable to Connect');