<?php

  $posId = $_POST['posId'];
  $body = $_POST['body']; 
  $cost = $_POST['cost'];
  $currency = $_POST['currency'];
  $end = $_POST['end']; 
  $start = $_POST['start'];
  $span = $_POST['span'];
  $uFireId = $_POST['uFireId'];
  $uEmail = $_POST['uEmail'];
  $uName = $_POST['uName'];
  $uPhone = $_POST['uPhone'];
  $uPhoto = $_POST['uPhoto'];
  $status = "0";
  $response = array();
  
  $postdetails = array(
      'posId' => $posId,
      'body' => $body,
      'cost' => $cost,
      'currency' => $currency,
      'end' => $end,
      'start' => $start,
      'span' => $span,
      'status' => $status,
      'uFireId' => $uFireId,
      'uEmail' => $uEmail,
      'uName' => $uName,
      'uPhone' => $uPhone,
      'uPhoto' => $uPhoto,
);
  
//Check if all fieds are given
if (empty($start) || empty($end) || empty($cost) || empty($span)) {
    $response['success'] = "0";
    $response['message'] = "Some fields are empty. Please try again!";
    echo json_encode($response);
    die;
}  
  
  //Insert the user into the database
if (addPost($postdetails)) {
    $response['success'] = "1";
    $response['message'] = "Post added successfully!";
    echo json_encode($response);
} else {
    $response['success'] = "0";
    $response['message'] = "Posting ad failed. Please try again!";
    echo json_encode($response);
}
  
 function addPost($postdetails) {
        include('mDbOps.php');
        $query = "INSERT INTO daletsys_azyma.bookings (posId, body, cost,currency,end, start,span,status,uFireId,uEmail,uName,uPhone,uPhoto) VALUES "
                . "(:posId, :body, :cost,:currency,:end, :start,:span,:status, :uFireId,:uEmail,:uName,:uPhone,:uPhoto)";
        $stmt = $pdo->prepare($query);
        return $stmt->execute($postdetails);
}
  
  
