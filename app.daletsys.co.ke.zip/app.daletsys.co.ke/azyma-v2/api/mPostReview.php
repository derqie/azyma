<?php

  $posId = $_POST['posId'];
  $body = $_POST['body'];
  $review = $_POST['review'];
  $uFireId = $_POST['uFireId'];
  $uEmail = $_POST['uEmail'];
  $uName = $_POST['uName'];
  $uPhone = $_POST['uPhone'];
  $uPhoto = $_POST['uPhoto'];
  $response = array();
  
  $postdetails = array(
      'posId' => $posId,
      'body' => $body,
      'review' => $review,
      'uFireId' => $uFireId,
      'uEmail' => $uEmail,
      'uName' => $uName,
      'uPhone' => $uPhone,
      'uPhoto' => $uPhoto,
);
  
  $postReview = array(
      'posIdRev' => $posId,
      'review' => $review,
      );
  
//Check if all fieds are given
if (empty($body) || empty($review) || empty($posId) || empty($uEmail)) {
    $response['success'] = "0";
    $response['message'] = "Some fields are empty. Please try again!";
    echo json_encode($response);
    die;
}  
  
  //Insert the user into the database
if (addPost($postdetails)) {
    
    if(updateReview($postReview)){
        $response['success'] = "1";
        $response['message'] = "Post added successfully!";
        echo json_encode($response);
    }
   
} else {
    $response['success'] = "0";
    $response['message'] = "Posting ad failed. Please try again!";
    echo json_encode($response);
}
  
 function addPost($postdetails) {
        include('mDbOps.php');
        $query = "INSERT INTO daletsys_azyma.reviews (posId, body, review, uFireId,uEmail,uName,uPhone,uPhoto) VALUES "
                . "(:posId, :body, :review, :uFireId,:uEmail,:uName,:uPhone,:uPhoto)";
         
        $stmt = $pdo->prepare($query);
        return $stmt->execute($postdetails);
    }
    
    //Update     
  function updateReview($postReview) {
    include('mDbOps.php');
    
    $querySelectAll = "SELECT AVG(reviewed) FROM daletsys_azyma.posts WHERE posId = :posIdRev";
    $stmtAvg = $pdo->prepare($querySelectAll);
    $stmtAvg = $stmtAvg->execute($querySelectAll);

    $stmtNAvg = $stmtAvg;
    $queryRev = "UPDATE daletsys_azyma.posts SET reviewed = :review  WHERE posId = :posIdRev";
    //$queryRev = "UPDATE daletsys_azyma.posts SET reviewed = :review  WHERE posId = :posIdRev";
    $stmtRev = $pdo->prepare($queryRev);
    return $stmtRev->execute($postReview);
  }
