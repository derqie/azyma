<?php
	require_once('mDbOps.php');
	$posId = $_POST['posId'];
	$dateNow = date("Y-m-d h:i:sa");
	
	$result = $pdo->prepare("SELECT * FROM posts WHERE posId = '".$posId."' "); 
    $result->execute();
      	 
    for($i=0; $row = $result->fetch(); $i++){
        
        $status = $row['status'];
        
        if($status == "" || $status == "0"){//Deactivating a ppst
            $status = "1";
            
            //updates begin here
            $updates = $pdo -> prepare("UPDATE posts SET status = ?,updated = ? WHERE posId = ? ");
            $saves = $updates->execute([$status,$dateNow,$posId]);
        	
        	if($saves){
        	    $response['success'] = "0";
                $response['message'] = "Post was deactivated.";
                echo json_encode($response);
        	}else{
        	    $response['success'] = "1";
                $response['message'] = "Post was not deactivated.";
                echo json_encode($response);
        	}
        	
        }else{//Activating a ppst
            $status = "0";
            $updates = $pdo -> prepare("UPDATE posts SET status = ?,updated = ? WHERE posId = ? ");
            $saves = $updates->execute([$status,$dateNow,$posId]);
        	
        	if($saves){
        	    $response['success'] = "00";
                $response['message'] = "Post was activated.";
                echo json_encode($response);
        	}else{
        	    $response['success'] = "11";
                $response['message'] = "Post was not activated.";
                echo json_encode($response);
        	}
        }
        
    }
	

   
?>