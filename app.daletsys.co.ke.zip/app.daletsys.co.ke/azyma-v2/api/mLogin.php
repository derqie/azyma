<?php
$user = $_POST['email'];
$password = $_POST['password'];
$response = array();

$userdetails = array(
    'user' => $user,
    'password' => md5($password)
);

$ldates = date("l jS \of F Y h:i:s A");
$updatedetails = array(
    'lastLoggedOn' => $ldates,
    'email' => $user
);
 
$success = loginUser($userdetails);
$updated = updateLogin($updatedetails);
 
if (empty($user) || empty($password)) {
    $response['success'] = "0";
    $response['message'] = "Some fields are empty. Please try again!";
    echo json_encode($response);
    die;
}
 
 
if (checkEmail($user)) {
    
   if (!empty($success)) {
        if(!empty($updated)){
            $response['success'] = "1";
            $response['message'] = "Login successfully!";
            $response['details'] = $success;
            echo json_encode($response);
        }else{
            $response['success'] = "0";
            $response['message'] = "Login failed. Please try again!";
            echo json_encode($response);
        }
       
    } else {
        $response['success'] = "0";
        $response['message'] = "Login failed. Please try again!";
        echo json_encode($response);
    }
    
}else{
    $response['success'] = "2";
    $response['message'] = "That email is not registered. Please Register!";
    echo json_encode($response);
    die();
}

function updateLogin($updatedetails){
    include('mDbOps.php');
    $query = "UPDATE daletsys_azyma.users SET lastLoggedOn = :lastLoggedOn  WHERE email = :email";
        $stmt = $pdo->prepare($query);
        return $stmt->execute($updatedetails);
}

function loginUser($userdetails) {
    include('mDbOps.php');
    $array = array();
    $stmt = $pdo->prepare("SELECT * FROM users WHERE (email = :user OR username = :user ) AND password = :password");
    $stmt->execute($userdetails);
    $array = $stmt->fetch(PDO::FETCH_ASSOC);
    $stmt = null;
    return $array;
}

function checkEmail($value) {
        include('mDbOps.php');
        $stmt = $pdo->prepare("SELECT * FROM daletsys_azyma.users WHERE email = ? ");
        $stmt->execute([$value]);
        $array = $stmt->fetch(PDO::FETCH_ASSOC);
        $stmt = null;
        return !empty($array);
    }

