<?php
    require_once('mDbOps.php');
   
    $page = $_GET["page"];
    $offset = $_GET["offset"];
    $email = $_GET["email"];
    $status="1";
    
    $start = 0; 
    $limit = 3;
    
    $qTotal = $pdo->prepare("SELECT * from posts WHERE uEmail != '".$email."' AND status != '".$status."' ");
	$qTotal->execute();
    $total = $qTotal->rowCount();
    
    $page_limit = $total/$limit; 
    
    if($page<=$page_limit){
       
        $start = ($page - 1) * $limit;
        $query = "SELECT * FROM posts  WHERE uEmail != '".$email."' AND status != '".$status."'  ";//*
        $stmt = $pdo ->prepare($query);
        $stmt->execute();
          
        $stmt->execute(array("%$query%"));
        while($row = $stmt->fetch()) {
            $result[] = [
                "posId"=>$row['posId'],
                 "body"=>$row['body'],
                 "booked"=>$row['booked'],
                 "category"=>$row['category'],
                 "commented"=>$row['commented'],
                 "cost"=>$row['cost'],
                 "currency"=>$row['currency'],
                 "end"=>$row['end'],
                 "gallery"=>$row['gallery'],
                 "iLat"=>$row['iLat'],
                 "iLong"=>$row['iLong'],
                 "per"=>$row['per'],
                 "reviewed"=>$row['reviewed'],
                 "start"=>$row['start'],
                 "span"=>$row['span'],
                 "title"=>$row['title'],
                 "uFireId"=>$row['uFireId'],
                 "uEmail"=>$row['uEmail'],
                 "uName"=>$row['uName'],
                 "uPhone"=>$row['uPhone'],
                 "uPhoto"=>$row['uPhoto'],
                 "updated"=>$row['updated'],
                 "status"=>$row['status'], 
                 "views"=>$row['views'], 
                 "created"=>$row['created']
                 
            ];
    } 
        
    echo json_encode($result); 
 

}else{
   echo "over";
}
    
    