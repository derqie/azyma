<?php

  $posId = $_POST['posId'];
  $body = $_POST['body'];
  $booked = $_POST['booked'];
  $category = $_POST['category'];
  $commented = $_POST['commented'];
  $cost = $_POST['cost'];
  $currency = $_POST['currency'];
  $end = $_POST['end'];
  $gallery = $_POST['gallery'];
  $iLat = $_POST['iLat'];
  $iLong = $_POST['iLong'];
  $per = $_POST['per'];
  $reviewed = $_POST['reviewed'];
  $start = $_POST['start'];
  $span = $_POST['span'];
  $title = $_POST['title'];
  $uFireId = $_POST['uFireId'];
  $uEmail = $_POST['uEmail'];
  $uName = $_POST['uName'];
  $uPhone = $_POST['uPhone'];
  $uPhoto = $_POST['uPhoto'];
  $response = array();
  
  $postdetails = array(
      'posId' => $posId,
      'body' => $body,
      'booked' => $booked,
      'category' => $category,
      'commented' => $commented,
      'cost' => $cost,
      'currency' => $currency,
      'end' => $end,
      'gallery' => $gallery,
      'iLat' => $iLat,
      'iLong' => $iLong,
      'per' => $per,
      'reviewed' => $reviewed,
      'start' => $start,
      'span' => $span,
      'title' => $title,
      'uFireId' => $uFireId,
      'uEmail' => $uEmail,
      'uName' => $uName,
      'uPhone' => $uPhone,
      'uPhoto' => $uPhoto,
);
  
//Check if all fieds are given
if (empty($body) || empty($title) || empty($cost) || empty($category)) {
    $response['success'] = "0";
    $response['message'] = "Some fields are empty. Please try again!";
    echo json_encode($response);
    die;
}  
  
  //Insert the user into the database
if (addPost($postdetails)) {
    $response['success'] = "1";
    $response['message'] = "Post added successfully!";
    echo json_encode($response);
} else {
    $response['success'] = "0";
    $response['message'] = "Posting ad failed. Please try again!";
    echo json_encode($response);
}
  
 function addPost($postdetails) {
        include('mDbOps.php');
        $query = "INSERT INTO daletsys_azyma.posts (posId,  body, booked, category,commented,cost,currency,end,gallery,iLat,iLong,per,reviewed,start,span,title,uFireId,uEmail,uName,uPhone,uPhoto) VALUES "
                . "(:posId, :body, :booked, :category, :commented,:cost,:currency,:end,:gallery,:iLat,:iLong,:per,:reviewed,:start,:span,:title,:uFireId,:uEmail,:uName,:uPhone,:uPhoto)";
        $stmt = $pdo->prepare($query);
        return $stmt->execute($postdetails);
}
  
  
