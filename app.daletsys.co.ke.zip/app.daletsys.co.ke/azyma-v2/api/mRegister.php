<?php
$fUser = $_POST['fUser'];
$firstname = $_POST['name'];
$username = $_POST['username'];
$email = $_POST['email'];
$password = $_POST['password'];
$password1 = $_POST['password1'];
$status = $_POST['status'];
$response = array();

$userdetails = array(
    'fUser' => $fUser,
    'firstname' => $firstname,
    'username' => $username,
    'email' => $email,
    'password' => md5($password),
    'status' => $status,
);

//Check if all fieds are given
if (empty($firstname) || empty($username) || empty($email) || empty($password) || empty($fUser)) {
    $response['success'] = "0";
    $response['message'] = "Some fields are empty. Please try again!";
    echo json_encode($response);
    die;
}
//Check if password match
if ($password !== $password1) {
    $response['success'] = "0";
    $response['message'] = "Password mistmatch. Please try again!";
    echo json_encode($response);
    die();
}
//Check if email is a valid one
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $response['success'] = "0";
    $response['message'] = "Invalid email. Please try again!";
    echo json_encode($response);
    die();
}

//Check if email exists
if (checkEmail($email)) {
    $response['success'] = "2";
    $response['message'] = "That email is registered. Please try again!";
    echo json_encode($response);
    die();
}

//Check if email exists
if (checkUsername($username)) {
    $response['success'] = "2";
    $response['message'] = "That username is registered. Please try again!";
    echo json_encode($response);
    die();
}

//Insert the user into the database
if (registerUser($userdetails)) {
    $response['success'] = "1";
    $response['message'] = "User registered successfully!";
    echo json_encode($response);
} else {
    $response['success'] = "0";
    $response['message'] = "User registration failed. Please try again!";
    echo json_encode($response);
}
 
 function registerUser($userdetails) {
        include('mDbOps.php');
        $query = "INSERT INTO daletsys_azyma.users (fUser,firstname,  username, email, password, status) VALUES "
                . "(:fUser,:firstname, :username, :email, :password, :status)";
        $stmt = $pdo->prepare($query);
        return $stmt->execute($userdetails);
    }
    
 function checkEmail($value) {
        include('mDbOps.php');
        $stmt = $pdo->prepare("SELECT * FROM daletsys_azyma.users WHERE email = ? ");
        $stmt->execute([$value]);
        $array = $stmt->fetch(PDO::FETCH_ASSOC);
        $stmt = null;
        return !empty($array);
    }
    
 function checkUsername($value) {
        include('mDbOps.php');
        $stmt = $pdo->prepare("SELECT * FROM daletsys_azyma.users WHERE username = ? ");
        
        $stmt->execute([$value]);
        $array = $stmt->fetch(PDO::FETCH_ASSOC);
        $stmt = null;
        return !empty($array);
        
 }
    